﻿if (Test-Path ".\tools\make.ps1") { . .\tools\make.ps1 }

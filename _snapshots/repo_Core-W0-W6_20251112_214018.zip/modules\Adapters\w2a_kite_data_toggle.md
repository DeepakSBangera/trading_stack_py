﻿# W2A — Zerodha Kite Data Toggle (Read-Only)
- Mode: **disabled** by default; PIT-safe only.
- When enabled: read-only fetch -> staging files under data/kite/ with manifest logs.
- Never overrides backtest-vetted rules without change log + canary.

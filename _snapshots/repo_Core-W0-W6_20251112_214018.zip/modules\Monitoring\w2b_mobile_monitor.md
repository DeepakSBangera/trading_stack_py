﻿# W2B — Mobile Monitor (Telegram) — Placeholder
- Alerts: daily buylist, gate breaches, kill-switch triggers.
- Delivery: Telegram bot; message schema stabilized, implementation TBA.

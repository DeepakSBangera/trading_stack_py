﻿# Sector & Factor Caps
Beta/style/sector exposure caps; penalties at allocator

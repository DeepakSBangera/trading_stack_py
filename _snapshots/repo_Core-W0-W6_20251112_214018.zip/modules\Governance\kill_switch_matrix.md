﻿# Kill-Switch Matrix
Condition → Action (halt adds / derisk 25–50% / revert Aggressive→Base / notify)

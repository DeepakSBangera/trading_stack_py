﻿# Data Lineage
## Manifest fields
## Hashing rules
## Retention & replay

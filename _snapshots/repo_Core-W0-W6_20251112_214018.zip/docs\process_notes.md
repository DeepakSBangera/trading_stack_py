# Week-0 notes

W1 baseline generated and validated.
W1 baseline generated and validated.



## W10 � SARIMAX Baseline

Run: make w10 (writes reports/wk10\_forecast\_eval.csv). Order is configurable via --order p,d,q.



\## W12 � Kelly + DD throttle

Run: `python scripts/w12\_kelly\_dd.py --out reports/wk12\_kelly\_dd.csv`

Output columns: date, kelly\_fraction, target\_vol, dd\_throttle, position\_scale

�W6: EW vs shrinkage MV baseline added; CI schema test in place.




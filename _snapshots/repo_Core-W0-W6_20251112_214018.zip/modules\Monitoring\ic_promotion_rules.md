﻿# IC Promotion Rules
IC & half-life thresholds to promote/retire signals

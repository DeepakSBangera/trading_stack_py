﻿# Pre-Trade Checklist
ADV%, event calendar, tax lots; log violations

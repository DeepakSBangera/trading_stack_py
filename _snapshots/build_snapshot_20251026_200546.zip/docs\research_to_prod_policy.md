﻿# Research→Prod Policy
- Sandbox → Canary (1–5%) → Full
- Gates required: W0 gates + W5 (DSR/PBO) + risk sign-off
- Freeze during W20

# W5 Walk-Forward Report

- Segments: **0**
- Mean segment SR: **nan**
- DSR over segment SRs (N=0): **0.000**
- MTL (PSR≥90%): **nan periods**
- MTL (PSR≥95%): **nan periods**

## Segments (first 5)


# W5 Walk-Forward Report

- Data source: **toy_prices.csv** (returns source: **close_pct_change**)
- Observations used: **9**
- Train/Test/Step/Expanding/Embargo: **5 / 2 / 2 / True / 1**
- Segments: **0**
- Mean segment SR: **nan**
- DSR over segment SRs (N=0): **0.000**
- MTL (PSR≥90%): **nan periods**
- MTL (PSR≥95%): **nan periods**

## Segments (first 10)


SELECT 42 AS answer;

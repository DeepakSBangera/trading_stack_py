from __future__ import annotations
import numpy as np
import pandas as pd

from tradingstack.metrics.sharpe import sharpe_ratio as _point_sharpe  # parity import
from tradingstack.metrics.sortino import sortino_ratio as _point_sortino
from tradingstack.metrics.drawdown import max_drawdown as _point_max_dd
from tradingstack.utils.dates import normalize_date_index

def _to_ret_from_nav(nav: pd.Series) -> pd.Series:
    nav = nav.astype("float64")
    ret = nav.pct_change()
    return ret.replace([np.inf, -np.inf], np.nan).dropna()

def rolling_volatility(returns: pd.Series, window: int = 63, annualization: int = 252) -> pd.Series:
    returns = returns.astype("float64")
    vol = returns.rolling(window=window, min_periods=window).std(ddof=1)
    return vol * np.sqrt(annualization)

def rolling_sharpe(returns: pd.Series, window: int = 252, annualization: int = 252, rf: float = 0.0) -> pd.Series:
    excess = returns - rf
    mean = excess.rolling(window=window, min_periods=window).mean()
    std = excess.rolling(window=window, min_periods=window).std(ddof=1)
    sharpe = (mean / std) * np.sqrt(annualization)
    return sharpe.replace([np.inf, -np.inf], np.nan)

def rolling_sortino(returns: pd.Series, window: int = 252, annualization: int = 252, rf: float = 0.0) -> pd.Series:
    excess = returns - rf
    downside = excess.clip(upper=0.0)
    dd = np.sqrt((downside.pow(2)).rolling(window=window, min_periods=window).mean())
    mu = excess.rolling(window=window, min_periods=window).mean()
    sortino = (mu / dd) * np.sqrt(annualization)
    return sortino.replace([np.inf, -np.inf], np.nan)

def rolling_drawdown(nav: pd.Series, window: int = 252) -> pd.Series:
    """
    Rolling maximum drawdown over each sliding window (<= 0).
    """
    nav = nav.astype("float64")
    def _window_mdd(x: pd.Series) -> float:
        peak = x.cummax()
        dd = x / peak - 1.0
        return dd.min()
    return nav.rolling(window=window, min_periods=window).apply(_window_mdd, raw=False)

def trend_regime(nav: pd.Series, fast: int = 50, slow: int = 200, method: str = "sma_crossover") -> pd.Series:
    """
    - 'sma_crossover': +1 if SMA(fast) > SMA(slow), -1 if <, 0 otherwise.
    - 'zscore': sign(zscore(nav, slow)).
    Returns int8 series in {-1, 0, +1}.
    """
    nav = nav.astype("float64")
    if method == "sma_crossover":
        f = nav.rolling(fast, min_periods=fast).mean()
        s = nav.rolling(slow, min_periods=slow).mean()
        reg = pd.Series(0, index=nav.index, dtype="int8")
        reg = reg.mask(f > s, 1)
        reg = reg.mask(f < s, -1)
        return reg
    elif method == "zscore":
        m = nav.rolling(slow, min_periods=slow).mean()
        sd = nav.rolling(slow, min_periods=slow).std(ddof=1)
        z = (nav - m) / sd
        reg = pd.Series(0, index=nav.index, dtype="int8")
        reg = reg.mask(z > 0, 1)
        reg = reg.mask(z < 0, -1)
        return reg
    else:
        raise ValueError(f"Unknown trend regime method: {method}")

def compute_rolling_metrics_from_nav(
    df: pd.DataFrame,
    nav_col: str = "_nav",
    ret_window_sharpe: int = 252,
    ret_window_sortino: int = 252,
    vol_window: int = 63,
    dd_window: int = 252,
    annualization: int = 252,
    rf_per_period: float = 0.0,
    regime_method: str = "sma_crossover",
    regime_fast: int = 50,
    regime_slow: int = 200,
) -> pd.DataFrame:
    """
    Input: DataFrame with 'date' column or DatetimeIndex and a NAV column (nav_col).
    Output: DataFrame with rolling metrics aligned to input index.
    """
    df = normalize_date_index(df, "date")
    nav = df[nav_col].astype("float64")
    rets = _to_ret_from_nav(nav)

    out = pd.DataFrame(index=df.index)
    out["rolling_vol"] = rolling_volatility(rets, window=vol_window, annualization=annualization)
    out["rolling_sharpe"] = rolling_sharpe(rets, window=ret_window_sharpe, annualization=annualization, rf=rf_per_period)
    out["rolling_sortino"] = rolling_sortino(rets, window=ret_window_sortino, annualization=annualization, rf=rf_per_period)
    out["rolling_mdd"] = rolling_drawdown(nav, window=dd_window)
    out["regime"] = trend_regime(nav, fast=regime_fast, slow=regime_slow, method=regime_method).astype("int8")
    return out

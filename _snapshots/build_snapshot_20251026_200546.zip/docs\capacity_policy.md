﻿# Capacity Policy
ADV% caps, min ₹ADV, update cadence, exception process
